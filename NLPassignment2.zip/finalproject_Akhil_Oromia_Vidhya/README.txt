This project contains code for assignment 2 of the course Natural Language Processing Technology 2022 at VU Amsterdam put together by Akhil chandran, Oromia Sergo and Vidhya Narayanasamy.

References:

The detailed description of the dataset collection and annotation procedures can be found https://aclanthology.org/N19-1144.pdf
The data in data/original is a small subset from https://github.com/idontflow/OLID. Check data/original/README.md for details.

The dataset was preprocessed such that label ‘1’ corresponds to offensive messages (‘OFF’ in the dataset description paper) and ‘0’ to non-offensive messages (‘NOT’ in the dataset description paper)

Your task:
Make sure to install the libraries in requirements.txt.

- For task3 of Part A of the assignment, You need to enable GPUs for the notebook:
	●	navigate to Edit → Notebook Settings
	●	select GPU from the Hardware Accelerator drop-down


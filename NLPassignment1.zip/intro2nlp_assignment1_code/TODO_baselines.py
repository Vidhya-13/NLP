
from collections import Counter
from random import seed
from random import randrange
from wordfreq import word_frequency

import numpy as np
import pandas as pd


def random_baseline(train_sentences, train_labels, testinput, testlabels):
    matched_df = get_dataframe(train_sentences, train_labels)
    seed(20)
    classes = list(set(matched_df['labels']))
    words_test = getList(testinput)
    labels_test = getList(testlabels)
    accuracy = []
    for i in range(100):
        instance_predictions = [classes[randrange(len(classes))] for word in words_test]
        predictions = {'words': words_test, 'predicted_labels': instance_predictions, 'actual_labels': labels_test}
        predictions = pd.DataFrame(predictions)
        correct_predictions = predictions[predictions['predicted_labels'] == predictions['actual_labels']]
        accuracy.append(round(len(correct_predictions) / len(predictions), 2))
    accuracy = round(np.average(accuracy), 3)


    precision_c, recall_c, F1_c = confusionMatrix(predictions, 'C')
    precision_n, recall_n, F1_n = confusionMatrix(predictions, 'N')
    c = Counter(labels_test)
    c = {word: count for word, count in c.items()}
    weighted_avg = ((c['C'] * F1_c) + (c['N'] * F1_n)) / (c['C'] + c['N'])
    return {'accuracy': accuracy, 'weighted_avg': round(weighted_avg, 2), 'class_C': [precision_c, recall_c, F1_c],
            'class_N': [precision_n, recall_n, F1_n]}, predictions


def majority_baseline(train_sentences, train_labels, testinput, testlabels):

    matched_df = get_dataframe(train_sentences, train_labels)

    majority_class = Counter(matched_df['labels']).most_common(1)[0]
    majority_class = majority_class[0]
    words_test = getList(testinput)
    labels_test = getList(testlabels)

    instance_predictions = [majority_class for word in words_test]
    predictions = {'words': words_test, 'predicted_labels':instance_predictions, 'actual_labels': labels_test}
    predictions = pd.DataFrame(predictions)
    correct_predictions = predictions[predictions['predicted_labels'] == predictions['actual_labels']]
    accuracy = round(len(correct_predictions)/len(predictions), 2)


    precision_c, recall_c, F1_c = confusionMatrix(predictions, 'C')
    precision_n, recall_n, F1_n = confusionMatrix(predictions, 'N')
    c = Counter(labels_test)
    c = {word: count for word, count in c.items()}
    weighted_avg = ((c['C'] * F1_c) + (c['N'] * F1_n)) / (c['C'] + c['N'])
    return {'accuracy': accuracy, 'weighted_avg': round(weighted_avg, 2), 'class_C': [precision_c, recall_c, F1_c],
            'class_N': [precision_n, recall_n, F1_n]}, predictions


## length threshold-- Assuming words above the average word length threshold as difficult
def length_baseline(train_sentences, train_labels, testinput, testlabels):
    # Based on the scatter plot, and accuracy of the dev_data length threshold == 8

    matched_df = get_dataframe(train_sentences, train_labels)

    # words_len = [len(word) for word in matched_df['words']]
    # average_words_len = round(sum(words_len)/len(words_len), 2)
    # print(average_words_len)

    word_len_threshold = 8
    words_test = getList(testinput)
    labels_test = getList(testlabels)

    instance_predictions = ['N' if len(word) < word_len_threshold else 'C' for word in words_test]
    # print(instance_predictions, '\n', words_test)
    predictions = {'words': words_test, 'predicted_labels': instance_predictions, 'actual_labels': labels_test}
    predictions = pd.DataFrame(predictions)
    correct_predictions = predictions[predictions['predicted_labels'] == predictions['actual_labels']]
    accuracy = round(len(correct_predictions)/len(predictions), 2)

    precision_c, recall_c, F1_c = confusionMatrix(predictions, 'C')
    precision_n, recall_n, F1_n = confusionMatrix(predictions, 'N')
    c = Counter(labels_test)
    c = {word: count for word, count in c.items()}
    weighted_avg = ((c['C'] * F1_c) + (c['N'] * F1_n)) / (c['C'] + c['N'])
    return {'accuracy': accuracy, 'weighted_avg': round(weighted_avg, 2), 'class_C': [precision_c, recall_c, F1_c],
            'class_N': [precision_n, recall_n, F1_n]}, predictions


def frequency_baseline(train_sentences, train_labels, testinput, testlabels):
    # Based on the scatter plot, and the dev data set frequency threshold == 0.01

    matched_df = get_dataframe(train_sentences, train_labels)

    # words_frq = [word_frequency(word, 'en') for word in matched_df['words']]
    # average_words_frq = round(sum(words_frq) / len(words_frq), 2)
    # print(average_words_frq)

    words_test = getList(testinput)
    labels_test = getList(testlabels)
    ##not complex if probablistic word complexity > 0.05
    instance_predictions = ['N' if word_frequency(word, 'en') > 0.01 else 'C' for word in words_test]
    # print(instance_predictions, '\n', words_test)
    predictions = {'words': words_test, 'predicted_labels': instance_predictions, 'actual_labels': labels_test}
    predictions = pd.DataFrame(predictions)
    correct_predictions = predictions[predictions['predicted_labels'] == predictions['actual_labels']]
    accuracy = round(len(correct_predictions)/len(predictions), 2)

    precision_c, recall_c, F1_c = confusionMatrix(predictions, 'C')
    precision_n, recall_n, F1_n = confusionMatrix(predictions, 'N')
    c = Counter(labels_test)
    c = {word:count for word, count in c.items()}
    weighted_avg = ((c['C'] * F1_c) + (c['N'] * F1_n))/(c['C'] + c['N'])
    return {'accuracy':accuracy, 'weighted_avg': round(weighted_avg, 2), 'class_C': [precision_c, recall_c, F1_c], 'class_N': [precision_n, recall_n, F1_n]}, predictions


def divide(num, den):
    return num / den if den else 0

def calculations(Tp, Fp, Fn):
    precision = divide(Tp, (Tp + Fp))
    recall = divide(Tp, (Tp + Fn))
    F1 = 2 * divide((precision * recall), (precision + recall))
    return round(precision, 2), round(recall, 2), round(F1, 2)

def confusionMatrix(predictions, label):

    if label == 'C':
        ##Assuming complex class is postive
        ##False pridictions
        Not_predictions = predictions[predictions['predicted_labels'] == 'N']

        ##False Negative
        missed_Complex = Not_predictions[Not_predictions['actual_labels'] == 'C']

        # True pridictions
        complex_predictions = predictions[predictions['predicted_labels'] == 'C']
        correct_complex = complex_predictions[complex_predictions['actual_labels'] == 'C']

        ##False postive
        wrong_complex = complex_predictions[complex_predictions['actual_labels'] == 'N']

        # precision = divide(len(correct_complex), (len(correct_complex) + len(wrong_complex)))
        # recall = divide(len(correct_complex), (len(correct_complex) + len(missed_Complex)))
        # F1 = 2 * divide((precision * recall), (precision + recall))
        precision, recall, F1 = calculations(len(correct_complex), len(wrong_complex), len(missed_Complex))
        return precision, recall, F1
    elif label == 'N':
        ##Assuming Non complex class is postive
        ##True pridictions
        Not_predictions = predictions[predictions['predicted_labels'] == 'N']
        correct_not = Not_predictions[Not_predictions['predicted_labels'] == 'N']

        ##False Negative
        complex_predictions = predictions[predictions['predicted_labels'] == 'C']
        missed_NotC_class = complex_predictions[complex_predictions['actual_labels'] == 'N']

        # False Positive
        complex_predictions = Not_predictions[Not_predictions['actual_labels'] == 'C']

        # precision = divide(len(correct_complex), (len(correct_complex) + len(wrong_complex)))
        # recall = divide(len(correct_complex), (len(correct_complex) + len(missed_Complex)))
        # F1 = 2 * divide((precision * recall), (precision + recall))
        precision, recall, F1 = calculations(len(correct_not), len(complex_predictions), len(missed_NotC_class))
        return precision, recall, F1

#read file line by line and remove newline,
# punctuations are not removed
def readFile(filePath):
    with open(filePath) as file:
        file = file.read().splitlines()
    return file


#to get list of sentences as list of words
def getList(input_list):
    words = []
    for sentence in input_list:
        for word in sentence.split():
            words.append(word)
    return words

def get_dataframe(inputdata, labels):
    data = getList(inputdata)
    label = getList(labels)
    matched = {'words': data, 'labels': label}
    return pd.DataFrame(matched)


if __name__ == '__main__':
    train_path = "data/preprocessed/train/"
    dev_path = "data/preprocessed/val/"
    test_path = "data/preprocessed/test/"

    # Note: this loads all instances into memory. If you work with bigger files in the future, use an iterator instead.

    train_sentences = readFile(train_path + "sentences.txt")
    train_labels = readFile(train_path + "labels.txt")
    dev_sentences = readFile(dev_path + "sentences.txt")
    dev_labels = readFile(dev_path + "labels.txt")
    testinput = readFile(test_path + "sentences.txt")
    testlabels = readFile(test_path + "labels.txt")

    #majority baseline

    dev_mj, predictions_dev_mj = majority_baseline(train_sentences, train_labels, dev_sentences, dev_labels)
    test_mj, predictions_test_mj = majority_baseline(train_sentences, train_labels, testinput, testlabels)
    #
    # #random baseline
    #
    dev_random, predictions_dev_random = random_baseline(train_sentences, train_labels, dev_sentences, dev_labels)
    test_random, predictions_test_random = random_baseline(train_sentences, train_labels, testinput, testlabels)

    #length
    dev_len, predictions_dev_len = length_baseline(train_sentences, train_labels, dev_sentences, dev_labels)
    test_len, predictions_test_len = length_baseline(train_sentences, train_labels, testinput, testlabels)

    #Frequency
    dev_freq, predictions_dev_freq = frequency_baseline(train_sentences, train_labels, dev_sentences, dev_labels)
    test_freq, predictions_test_freq = frequency_baseline(train_sentences, train_labels, testinput, testlabels)



    print('Random baseline: test:', test_random)
    print('majority baseline: test:', test_mj)
    print('Len baseline: test:', test_len)
    print('Freq baseline: test:', test_freq)
from sklearn.metrics import f1_score
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

def fscore(file_ext):
    # Over data as pandas dataframe.
    #
    read_tsv = pd.read_csv("experiments/base_model/model_output_"+file_ext+".tsv", sep='\t', encoding='latin-1')

    # Re-arrange dataframe. Remove rows with NaN values.
    # 
    read_tsv = read_tsv.shift(periods=1)
    read_tsv[str(read_tsv.columns[0])][0], read_tsv[str(read_tsv.columns[1])][0], read_tsv[str(read_tsv.columns[2])][0] = (read_tsv.columns)
    read_tsv.rename(columns = {str(read_tsv.columns[0]) : 'tokens', str(read_tsv.columns[1]) : 'labels', str(read_tsv.columns[2]) : 'pred'}, inplace = True)
    read_tsv = read_tsv.drop(read_tsv[read_tsv['pred'].isna()].index)

    # Assert string values. 
    #
    y_true1 = read_tsv['labels'].astype(str)
    y_true = np.array(y_true1)
    y_pred1 = read_tsv['pred'].astype(str)
    y_pred = np.array(y_pred1)

    # Return f1-score.
    #
    return f1_score(y_true, y_pred, average='weighted')

if __name__ == '__main__':
    file_ext = ['lr0.1', 'lr0.01', 'lr1e-3', 'lr1e-4', 'lr1e-5']    # Extensions to output file names.
    
    f_scores = []
    l_rates = [0.1, 0.01, 1e-3, 1e-4, 1e-5]     # Set of Learning Rates.
    
    # Returns F1-scores for each learning rate.
    #
    for ext in file_ext:
        f_scores.append(fscore(ext))
    
    # Plot Learning Rates against F1-Scores.
    #
    plt.plot(l_rates, f_scores, color='red', marker='o')
    plt.title('Learning Rates Vs. F1-Scores')
    plt.xlabel('Learning Rates')
    plt.ylabel('Weighted F1-Scores')
    plt.grid(True)
    plt.xticks(np.arange(min(l_rates), max(l_rates)+0.0001, 0.01))
    plt.show()
# Implement linguistic analyses using spacy
# Run them on data/preprocessed/train/sentences.txt
import numpy as np
import spacy
import pandas as pd
from scipy.stats import pearsonr
from wordfreq import word_frequency
import matplotlib.pyplot as plt

#import en_core_web_sm
#nlp = en_core_web_sm.load()
nlp = spacy.load("en_core_web_sm")

with open("data/preprocessed/train/sentences.txt", 'r', encoding='utf-8') as task1:
  filecontent = task1.read()
  doc = nlp(filecontent)

#PART A: Linguistic analysis using spaCy
#1.Tokenization
#No. of tokens and words
tokens = [token.text for token in doc if token.text != '\n']
words = [token.text for token in doc if token.text != '\n' and not token.is_punct]
print('Number of tokens:', len(tokens))
print('Number of words', len(words))

#Number of types
tok_type = []
for token in doc:
  if token.text != '\n' and token.text not in tok_type:
    tok_type.append(token.text)
print('Number of types:',len(tok_type))

# Average number of words per sentence = sum(len(no.of words per sentence))/total number of sentences
# Sentence Segmentation
sentences = doc.sents
sent = []
for sentence in sentences:
  sent.append(sentence)

num_sent = len(sent)
num_words = len(words)
avg1 = round(num_words / num_sent, 2)
print('Average number of words per sentence', avg1)

#Average word length = sum(len(words))/total number of words
chars = 0
for i in words[0:]:
  chars += len(i)
print('Sum of the length of words:', chars)  ##sum(len(words))

avg_wrd_len = round(chars/num_words,2)
print('Average word length:', avg_wrd_len,)

#2. Word Class
tokens = list()
fineTag = list()
uniTag = list()
for token in doc:
  if token.text != '\n':
    tokens.append(token.text)
    fineTag.append(token.tag_)
    uniTag.append(token.pos_)


postag = pd.DataFrame({'Finegrained': fineTag, 'Universal': uniTag, 'Token': tokens})

g = postag.groupby(['Finegrained', 'Universal', 'Token']).size().rename('Count')
mostFreq = g.groupby(['Finegrained', 'Universal'], group_keys=False).nlargest(3)
minFreq = g.groupby(['Finegrained', 'Universal'], group_keys=False).nsmallest(1)

freq = postag.groupby(['Finegrained', 'Universal']).size().reset_index(name='Occurrences')
# sort descending by occurrences
freq = freq.sort_values('Occurrences', ascending=False)
# add relative frequency
freq['Relative frequency (%)'] = round(freq['Occurrences'] / freq['Occurrences'].sum() * 100, 2)
# add top 3 most frequent tokens to dataframe
top3 = mostFreq.reset_index().groupby(['Finegrained', 'Universal'])['Token'].agg(lambda x: ', '.join(x.astype(str))).rename('Top 3 frequent')
freq = freq.merge(top3, on=['Finegrained', 'Universal'], how='left')
# add infrequent token to dataframe
bot = minFreq.reset_index(level=2)['Token'].rename('Infrequent')
freq = freq.merge(bot, on=['Finegrained', 'Universal'], how='left')
freq.head(10)

#3. N-Grams
#Token-Bigrams
import nltk, re, string, collections
from nltk.util import ngrams

enBigrams = ngrams(tokens, 2)
# get the frequency of each bigram in our corpus
enBigramFreq = collections.Counter(enBigrams)
# what are the three most popular bigrams?
enBigramFreq.most_common(3)

#Token-trigrams
enTrigrams = ngrams(tokens, 3)
enTrigramFreq = collections.Counter(enTrigrams)
enTrigramFreq.most_common(3)

#POS-Bigrams
posbigrams = ngrams(uniTag, 2)
posbigramFreq = collections.Counter(posbigrams)
posbigramFreq.most_common(3)

#POS-Trigrams
posTrigrams = ngrams(uniTag, 3)
posTrigramFreq = collections.Counter(posTrigrams)
posTrigramFreq.most_common(3)

#4. Lemmatization
sentences = doc.sents
sent = []
for sentence in sentences:
  #print(sentence)
  sent.append(sentence)
  for token in sentence:
    print(token.text, '\t', token.pos_, '\t', token.lemma, '\t', token.lemma_)

#5. Named Entity Recognition
from spacy import displacy
NER = spacy.load("en_core_web_sm")

#first five sentences given as input manually
doc1 = NER('''children are thought to be aged three , eight , and ten years , alongside an eighteen-month-old baby .
We mixed different concentrations of ROS with the spores , plated them out on petridishes with an agar-solution where fungus can grow on .
They feel they are under-represented in higher education and are suffering in a regional economic downturn .
Especially as it concerns a third party building up its military presence near our borders .
Police said three children were hospitalised for \"severe dehydration \" .''')

entity = []
label = []
for ent in doc.ents:
  entity.append(ent.text)
  label.append(ent.label_)
  print(ent.text,'\t', ent.label_)

print("Number of named entities:", len(entity))
print("Number of different entity labels:", len(set(label)))

#displacy.render(doc1, jupyter=True, style='ent')


##7 and 8
df = pd.read_csv('./data/original/english/WikiNews_Train.tsv',header=None, sep='\t')


label = collections.Counter(df[9])
label_0 = label[0]
label_1 = label[1]
print(label_0, label_1)


instances = df[4]
lenghts = []
ints = []
for instance in instances:
  inst = nlp(instance)
  len_ = len([token for token in inst])
  if len_ > 1:
    if len_ == 10:
      print(instance)
    lenghts.append(len_)
  else:
    ints.append(instance)
max = np.amax(lenghts)
print(len(lenghts), max)

df_new = pd.read_csv('./data/original/english/WikiNews_Train.tsv', header=None, sep='\t')
df_new = df_new[[4, 9, 10]]
# print(df_new[4])
# df_new[4] = df_new[4].str.split()
df_single_tokens = df_new[df_new[9] == 1]
single_tokens = pd.DataFrame(columns=[4, 9, 10, 'pos_tag'])
# print(df_single_tokens)#index, row in df.iterrows():
for indx, row in df_single_tokens.iterrows():
  inst = nlp(row[4])
  token = [token for token in inst]

  if len(token) == 1:
    tag = [tag.pos_ for tag in inst]
    row_n = {4: row[4], 9: row[9], 10: row[10], 'pos_tag': tag[0]}
    single_tokens = single_tokens.append(row_n, ignore_index=True)
print(single_tokens)

for token in single_tokens[4]:
  print(token)
  break

print(len(single_tokens))
single_tokens_length = [len(inst) for inst in single_tokens[4]]
single_tokens_freq = [word_frequency(str(inst), 'en') for inst in single_tokens[4]]

print(single_tokens_freq)


corr_coeff_len, _ = pearsonr(single_tokens_length, single_tokens[10])
corr_coeff_freq, _ = pearsonr(single_tokens_freq, single_tokens[10])

print(round(corr_coeff_len, 2), round(corr_coeff_freq, 2))

## 8

plt.scatter(x=single_tokens_length, y=single_tokens[10])
plt.title("token length Vs probablistic complexity")
plt.xlabel("token length")
plt.ylabel("probablistic complexity")
plt.show()

plt.scatter(x=single_tokens_freq, y=single_tokens[10])
plt.title("token frequency Vs probablistic complexity")
plt.xlabel("token frequency")
plt.ylabel("probablistic complexity")
plt.show()

plt.scatter(x=single_tokens['pos_tag'], y=single_tokens[10])
plt.title("token Pos-tag Vs probablistic complexity")
plt.xlabel("token Pos-tag")
plt.ylabel("probablistic complexity")
plt.show()
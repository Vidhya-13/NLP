# The original code only outputs the accuracy and the loss.
# Process the file model_output.tsv and calculate precision, recall, and F1 for each class

from sklearn.metrics import precision_recall_fscore_support
import pandas as pd
import numpy as np


def perform_metrics():
    # Over data as pandas dataframe.
    #
    read_tsv = pd.read_csv("experiments/base_model/model_output.tsv", sep='\t', encoding='latin-1')

    # Re-arrange dataframe. Remove rows with NaN values.
    # 
    read_tsv = read_tsv.shift(periods=1)
    read_tsv[str(read_tsv.columns[0])][0], read_tsv[str(read_tsv.columns[1])][0], read_tsv[str(read_tsv.columns[2])][0] = (read_tsv.columns)
    read_tsv.rename(columns = {str(read_tsv.columns[0]) : 'tokens', str(read_tsv.columns[1]) : 'labels', str(read_tsv.columns[2]) : 'pred'}, inplace = True)
    read_tsv = read_tsv.drop(read_tsv[read_tsv['pred'].isna()].index)

    # Assert string values. 
    #
    y_true1 = read_tsv['labels'].astype(str)
    y_true = np.array(y_true1)
    y_pred1 = read_tsv['pred'].astype(str)
    y_pred = np.array(y_pred1)

    # Metric- Precision, Recall & F1 score calculation.
    #
    metrics = [precision_recall_fscore_support(y_true, y_pred, labels='N', average='macro')[:-1], 
        precision_recall_fscore_support(y_true, y_pred, labels='C', average='macro')[:-1], 
        precision_recall_fscore_support(y_true, y_pred, average='weighted')[:-1]]

    df = pd.DataFrame(metrics, columns =['Precision', 'Recall', 'F-score'])
    df.index = ['Pos: N', 'Pos: C', 'Weighted']
    print(df)

if __name__ == '__main__':
    print(perform_metrics())
